<?php

class YZ_Wall_Tab {
  public function __construct() {
  }
}