-- fpv drone monster script
-- LoPhatKao Nov 2018

require("/scripts/vec2.lua")
require("/scripts/util.lua")
-- -----------------------------------------------------------------------------
function init()
  self.key = config.getParameter("droneKey")
  self.ownerId = config.getParameter("owner") -- doesnt work, always nil
  self.name = config.getParameter("name", "drone")
  self.spawning = true
  self.dead = false
  self.starttime = 2
  self.ownerId = nil
  self.cursorPos = nil
  self.angle = 0
  self.headlight = false
  self.spotangle = 0
  self.proMode = false
  self.brakes = false
  self.flySpeed = mcontroller.baseParameters().flySpeed
  self.proSpeed = (2 * mcontroller.baseParameters().flySpeed)

  monster.setName(self.name)
  monster.setDisplayNametag(true)

  self.spawnPos = mcontroller.position()
  self.movePos = self.spawnPos
  self.bounds = mcontroller.boundBox()
  self.w = self.bounds[3] - self.bounds[1]
  self.h = self.bounds[4] - self.bounds[2]

  status.addEphemeralEffect("monsterrelease")
  animator.setAnimationState("movement", "idle")-- idle/start/fly

  message.setHandler("cursorAt", function (_, _, args)
    if self.cursorPos == nil then self.cursorPos = {} end
    self.cursorPos[1] = args.pos.x
    self.cursorPos[2] = args.pos.y
    if not args.brakes then self.movePos = copy(self.cursorPos) end
  end) -- cursorAt

  message.setHandler("toggleLights", function (_, _, _)
    self.headlight = not self.headlight
    animator.setLightActive("flashlightBeam", self.headlight)
    animator.setLightActive("flashlightSpread", self.headlight)
    --    monster.say(string.format("%s", self.headlight))
  end) -- toggleLight

  message.setHandler("toggleProMode", function (_, _, proMode)
    self.proMode = proMode
    if self.proMode then
      animator.setAnimationState("movement", "toPro")
    else
      animator.setAnimationState("movement", "unPro")
    end
  end) -- togglePro

  message.setHandler("dropFlare", function (_, _, _)
    --    world.spawnProjectile("flare", vec2.add(mcontroller.position(), {0, - 1}), entity.id(), {0, - 1}, false, {speed = vec2.mag(mcontroller.velocity())})
    world.spawnProjectile("flare", vec2.add(mcontroller.position(), {0, - 1}), entity.id(), {mcontroller.facingDirection(), 0}, false,
    { processing = mcontroller.facingDirection() > 0 and "?flipxy" or "", speed = math.max(vec2.mag(mcontroller.velocity()) * 0.5, 2)})
  end) -- dropFlare

  message.setHandler("killDrone", function (_, _, _)
    damage({sourceId = entity.id(), sourceKind = "bugnet"})
  end) -- killDrone

  message.setHandler("setBeacon", function (_, _, pos)
    setBeacon(pos)
  end) -- setBeacon
end
-- -----------------------------------------------------------------------------
function setBeacon(pos)
  local bpos = pos
  if type(pos) == "number" then bpos = world.entityPosition(pos) end
  world.sendEntityMessage(self.ownerId, "droneBeaconPos", bpos)
end
-- -----------------------------------------------------------------------------
function update(dt)
  self.position = mcontroller.position()
  world.loadRegion({self.position[1] - self.w, self.position[2] - self.h, self.position[1] + self.w, self.position[2] + self.h})

  if self.dead or self.spawning then
    mcontroller.controlParameters({gravityEnabled = true})
  end

  if self.spawning then
    if entity.uniqueId() == nil then
      world.setUniqueId(entity.id(), self.key)
      local pids = world.entityQuery(self.position, 30, {includedTypes = {"player"}, order = "nearest"})
      for _, pid in pairs(pids) do
        if world.entityName(pid) == self.name then
          self.ownerId = pid
          break
        end
      end
    end
    if mcontroller.onGround() or mcontroller.zeroG() or mcontroller.liquidId() ~= 0 then -- touch ground/liquid or 0g
      self.spawning = false
      animator.setAnimationState("movement", "start")-- idle/start/fly
      local yvel = 4 + world.gravity(self.spawnPos) / 10
      mcontroller.setVelocity({0, yvel})
      world.sendEntityMessage(self.ownerId, "droneEID", {eid = entity.id()})
      animator.playSound("engineLoop", (-1)) -- loop forever -1
      animator.setSoundVolume("engineLoop", 0.5, 0)
    end
  elseif self.starttime >= 0 then
    self.starttime = self.starttime - dt -- spawning takeoff timer
    if self.starttime <= 0 then
      animator.setAnimationState("movement", "fly")
    end
  else
    -- calc tilt angle
    --    local maxSpeed = self.proMode and self.proSpeed or self.flySpeed
    self.angle = math.abs(mcontroller.xVelocity()) / self.proSpeed--(2 * maxSpeed)
    animator.setSoundVolume("engineLoop", 0.35 + (self.proMode and 0.15 or 0) + (0.5 * self.angle), 4)

    if self.headlight then --a + (b - a) * ratio
      local dangle = vec2.angle(world.distance(self.cursorPos, mcontroller.position()))
      if math.abs(dangle - self.spotangle) > 2 then -- snap to angle
        self.spotangle = dangle
      else -- lerp to angle
        self.spotangle = self.spotangle + (dangle - self.spotangle) * 0.5
      end
      --      monster.say(dangle) -- angle is 0-tau .. thought it was -pi to pi
      animator.resetTransformationGroup("spotlight")
      animator.rotateTransformationGroup("spotlight", mcontroller.facingDirection() < 0 and self.spotangle or math.pi - self.spotangle)
    end
    move(self.movePos)

  end
  animator.resetTransformationGroup("rotation")
  animator.rotateTransformationGroup("rotation", self.angle)
end
-- -----------------------------------------------------------------------------
function damage(args)
  if args.sourceKind == "bugnet" then
    status.setResourcePercentage("health", 0)
  else--  hax hp
    status.setResource("health", status.stat("maxHealth"))
  end
  if status.resource("health") <= 0 and not self.dead then
    self.dead = true
    animator.stopAllSounds("engineLoop")
    mcontroller.controlParameters({gravityEnabled = true})
    if animator.hasSound("dead") then animator.playSound("dead") end
  end
end
-- -----------------------------------------------------------------------------
function shouldDie()
  return self.dead
end
-- -----------------------------------------------------------------------------
function die()
  --  sb.logInfo("drone die()")
end
-- -----------------------------------------------------------------------------
function move(targetPosition)
  local flyTo = function(toTarget)
    local maxSpeed = self.proMode and self.proSpeed or self.flySpeed
    local nearSpeed = maxSpeed * (math.max(vec2.mag(toTarget) - 1, 0) / 15)
    mcontroller.controlApproachVelocity(vec2.mul(vec2.norm(toTarget), math.min(maxSpeed, nearSpeed)), mcontroller.baseParameters().airForce)
    mcontroller.controlDown()
  end

  local toTarget = world.distance(targetPosition, mcontroller.position())
  local targDir = util.toDirection(toTarget[1])
  --if targDir ~= mcontroller.facingDirection() then self.angle = 0 end
  mcontroller.controlFace(targDir)
  if not self.proMode and world.lineTileCollision(mcontroller.position(), targetPosition) then
    local searchParameters = {
      returnBest = false,
      mustEndOnGround = false,
      maxFScore = 400,
      maxNodesToSearch = 70000,
      boundBox = mcontroller.boundBox()
    }
    mcontroller.controlPathMove(targetPosition, false, searchParameters)
    if mcontroller.pathfinding() then
      flyTo(toTarget)
    end
  else
    flyTo(toTarget)
  end
end
