-- fpv drone monster script
-- LoPhatKao Nov 2018

require("/scripts/vec2.lua")
require("/scripts/util.lua")
-- -----------------------------------------------------------------------------
function init()
  self.drone = nil
  self.droneKey = nil
  self.spawning = false
  self.spawnPos = nil
  self.proMode = false
  self.tickcount = 0
  self.flareTimer = 0
  self.beaconFlashTimer = 0
  self.beaconFlashTime = 0.75
  self.beaconPos = nil
  self.seed = config.getParameter("droneSeed", nil)
  if self.seed == nil then
    resetSeed()
  end
  message.setHandler("droneBeaconPos", function(_, _, pos)
    --    sb.logInfo("%s ", pos)
    self.beaconPos = pos
  end)
  message.setHandler("droneEID", function(_, _, args)
    if not self.drone then self.drone = args.eid
  elseif self.drone ~= args.eid then
    world.sendEntityMessage(args.eid, "killDrone")
  end
end)
end
-- -----------------------------------------------------------------------------
function resetSeed()
self.seed = generateSeed() -- in util.lua
activeItem.setInstanceValue("droneSeed", self.seed)
end
-- -----------------------------------------------------------------------------
function activate(fireMode, shiftHeld)
if self.drone and world.entityExists(self.drone) then
  --- flying
  if fireMode == "primary" then
    -- Shift Lclick to set proMode
    if shiftHeld then
      self.proMode = not self.proMode
      world.sendEntityMessage(self.drone, "toggleProMode", self.proMode)
      animator.playSound("togglelight")
    else
      if self.flareTimer <= 0 then
        world.sendEntityMessage(self.drone, "dropFlare")
        self.flareTimer = 2
      end
    end
  end
  if fireMode == "alt" then
    if shiftHeld then -- shift + Rclick to kill
      setDrone(nil)
    else-- Rclick to toggle lights
      world.sendEntityMessage(self.drone, "toggleLights")
      animator.playSound("togglelight")
    end
  end
elseif (not self.drone and not self.spawning) then
  --- spawning
  -- check spawnarea beside player in facing dir
  local pid = activeItem.ownerEntityId()
  local ppos = world.entityPosition(pid)
  local dpos = vec2.add(ppos, {self.facingDirection * 4, 0})
  local droneBox = { dpos[1] - 2.5, dpos[2] - 2.5, dpos[1] + 2.5, dpos[2] + 2.5}
  if not world.rectTileCollision(droneBox, {"Null", "Block", "Dynamic", "Slippery"}) then
    -- spawn it
    if shiftHeld then resetSeed() end -- reset colors when shift held on spawn
    self.droneKey = sb.makeUuid() ---sb.logInfo("%s", pid)
    world.spawnMonster("fpvdrone", dpos, {seed = self.seed, owner = pid, droneKey = self.droneKey, name = world.entityName(pid)})
    self.spawnPos = dpos
    self.spawning = true
    self.beaconPos = ppos

  else
    animator.playSound("placeBad") -- play bad sound
  end
end
end
-- -----------------------------------------------------------------------------
function update(dt, fireMode, shiftHeld)
local ownerAim = activeItem.ownerAimPosition()
local aimPos = self.drone and world.entityPosition(self.drone) or ownerAim
self.aimAngle, self.facingDirection = activeItem.aimAngleAndDirection(0, aimPos)
activeItem.setFacingDirection(self.facingDirection)
--activeItem.setArmAngle(self.aimAngle)

if self.spawning and not self.drone then
  local mids = world.monsterQuery(self.spawnPos, 30)
  for _, mid in pairs(mids) do
    if world.entityUniqueId(mid) == self.droneKey then
      setDrone(mid)
      self.spawning = false
      break
    end
  end
end

if self.drone then
  if self.tickcount % 10 == 0 then
    world.sendEntityMessage(self.drone, "cursorAt", {pos = {x = ownerAim[1], y = ownerAim[2]}, brakes = shiftHeld})
  end
  if self.beaconPos then
    self.beaconFlashTimer = (self.beaconFlashTimer + dt) % self.beaconFlashTime
    drawBeacon()
  else
    self.beaconFlashTimer = 0
  end
end
if self.flareTimer > 0 then self.flareTimer = self.flareTimer - dt end
self.tickcount = self.tickcount + 1
end
-- -----------------------------------------------------------------------------
function setDrone(eid)
if eid == nil and self.drone then
  world.sendEntityMessage(self.drone, "killDrone")
  activeItem.setScriptedAnimationParameter("beaconVec", nil)
end
activeItem.setCameraFocusEntity(eid)
self.drone = eid
end
-- -----------------------------------------------------------------------------
function uninit()
setDrone(nil)
end
-- -----------------------------------------------------------------------------
function drawBeacon()
local dronepos = world.entityPosition(self.drone)
local beaconVec = world.distance(self.beaconPos, dronepos)

activeItem.setScriptedAnimationParameter("dronePos", dronepos)
activeItem.setScriptedAnimationParameter("beaconVec", beaconVec)
activeItem.setScriptedAnimationParameter("beaconFlash", (self.beaconFlashTimer / self.beaconFlashTime) < 0.5)

end
