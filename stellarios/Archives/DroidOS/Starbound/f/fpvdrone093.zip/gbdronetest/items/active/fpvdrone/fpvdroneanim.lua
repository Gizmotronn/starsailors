-- local animator func, for drone goal arrow
-- LoPhatKao Nov 2018

require("/scripts/vec2.lua")
require("/scripts/util.lua")
-- -----------------------------------------------------------------------------


function update(dt)
  localAnimator.clearDrawables()
  local beaconVec = animationConfig.animationParameter("beaconVec")
  if beaconVec then
    if (beaconVec[1]^2 + beaconVec[2]^2) >= 15^2 then
      local dronePos = animationConfig.animationParameter("dronePos")
      local beaconFlash = animationConfig.animationParameter("beaconFlash")
      local arrowAngle = vec2.angle(beaconVec)
      local arrowOffset = vec2.withAngle(arrowAngle, 5)
      --    sb.logInfo("%s %s", arrowAngle, arrowOffset)
      localAnimator.addDrawable({
        image = beaconVec[1] > 0 and "/scripts/deployment/beaconarrowright.png" or "/scripts/deployment/beaconarrowleft.png",
        --image = "/scripts/deployment/enemyarrow.png",
        rotation = arrowAngle,
        position = vec2.add(arrowOffset, dronePos),
        fullbright = true,
        centered = true,
        color = {255, 255, 255, beaconFlash and 150 or 50}
      }, "overlay")
    end
  end

end
