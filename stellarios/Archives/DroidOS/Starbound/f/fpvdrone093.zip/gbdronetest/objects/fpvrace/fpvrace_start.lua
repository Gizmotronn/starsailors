-- fpv race gate
-- LoPhatKao Nov 2018

-- timings: warn1 - register nearby drones with COMPUTER if placed
-- - warn3 - set all registered drones goal to wp(compy)/finish(manual)

-- state constants -1:err 0:inact 5:ready 4:warn1 3:earn2 2:warn3 1:green
local kERR, kOFF, kSTOP, kWRN1, kWRN2, kWRN3, kGRN = -1, 0, 1, 2, 3, 4, 5
local kNOCOMPYTITLE = "                    ^red;FPV RACE COMPUTER ERROR"

function init(v)
  if v then return end -- item placement virtual == true still?
  self.firstUpdate = true
  storage.uuid = storage.uuid or sb.makeUuid()
end

function update(dt)
  if self.firstUpdate then
    storage.lightstate = nil
    self.firstUpdate = nil
    onNodeConnectionChange()
  end
  object.setOutputNodeLevel(0, storage.lightstate == kGRN)
end

function onInteraction(args)
  --sb.logInfo("%s", args)
  return { "ShowPopup", { title = kNOCOMPYTITLE, message = "^red;[404]^reset; - FPVRACE_COMPUTER not found\n\n^yellow;[ MANUAL SETUP ]^reset;\n\n1) Wire a BUTTON (not a SWITCH!) to top of pole.\n2) Press button.\n3) ???\n4) Profit!"}}
end

function onNodeConnectionChange(args)
  --sb.logInfo("%s", args)
  local wired = object.isInputNodeConnected(0)
  object.setInteractive(config.getParameter("interactive", true) and not wired)
  if wired then updateAnimationState(kOFF)
  else updateAnimationState(kERR) end
end

function onInputNodeChange(args)
  --sb.logInfo("%s", args)
  if args.node == 0 then
  end
  --object.getInputNodeLevel(0)
end

function updateAnimationState(state)
  if storage.lightstate == state then return end
  storage.lightstate = state
  --if animator.animationState("baseState") ~= "warn1" then
  if state == kERR then
    animator.setAnimationState("baseState", "error")
  elseif state == kOFF then
    animator.setAnimationState("baseState", "inactive")
  elseif state == kSTOP then
    animator.setAnimationState("baseState", "stop")
  elseif state == kWRN1 then
    animator.setAnimationState("baseState", "warn1")
  elseif state == kWRN2 then
    animator.setAnimationState("baseState", "warn2")
  elseif state == kWRN3 then
    animator.setAnimationState("baseState", "warn3")
  elseif state == kGRN then
    animator.setAnimationState("baseState", "green")
  end
end
