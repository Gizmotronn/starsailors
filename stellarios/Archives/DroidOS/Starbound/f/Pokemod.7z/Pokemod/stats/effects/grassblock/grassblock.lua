function init()
   effect.addStatModifierGroup({{stat = "grassResistance", amount = 0.25}, {stat = "grassStatusImmunity", amount = 1}})

   script.setUpdateDelta(0)
end

function update(dt)

end

function uninit()
  
end
