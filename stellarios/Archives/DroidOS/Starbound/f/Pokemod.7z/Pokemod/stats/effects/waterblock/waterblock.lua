function init()
   effect.addStatModifierGroup({{stat = "waterResistance", amount = 0.25}, {stat = "waterStatusImmunity", amount = 1}})

   script.setUpdateDelta(0)
end

function update(dt)

end

function uninit()
  
end
