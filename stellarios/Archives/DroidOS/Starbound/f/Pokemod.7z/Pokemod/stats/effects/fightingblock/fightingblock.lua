function init()
   effect.addStatModifierGroup({{stat = "fightingResistance", amount = 0.25}, {stat = "fightingStatusImmunity", amount = 1}})

   script.setUpdateDelta(0)
end

function update(dt)

end

function uninit()
  
end
