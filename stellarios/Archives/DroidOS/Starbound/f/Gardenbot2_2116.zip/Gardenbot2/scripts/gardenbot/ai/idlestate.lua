--------------------------------------------------------------------------------
idleState = {}
--------------------------------------------------------------------------------
function idleState.enter()
  if self.state.hasState() then return nil,config.getParameter("gardenSettings.cooldown", 15) end
  return {}
end
--------------------------------------------------------------------------------
function idleState.update(dt, stateData)
  setAnimationState("movement", "idle")
  --world.logInfo("Idling")
  if not self.state.pickState() then
    --world.logInfo("No state found")
    local ignoreDist = math.random() <= 0.1 and true or false -- 10% chance to return
    self.state.pickState({ ignoreDistance = ignoreDist }) -- or only return when oob
  end
  return true,config.getParameter("gardenSettings.cooldown", 15)
end