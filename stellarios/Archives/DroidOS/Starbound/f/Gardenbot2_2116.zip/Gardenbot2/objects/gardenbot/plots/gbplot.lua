function init(virtual)
  --This tape will self-destruct in five seconds. Good luck, Jim.
  --entity.smash()
  script.setUpdateDelta(1)
end

function update()
  world.breakObject(entity.id(),true)
end