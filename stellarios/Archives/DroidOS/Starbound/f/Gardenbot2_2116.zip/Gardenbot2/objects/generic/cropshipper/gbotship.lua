-- gardenbot interactions with crop shippers (vanilla, vanilla mods, smallcropshipper, infinityshipper)
-- LoPhatKao - Octember 33rd, 2018

local oldInit = init
function init (...)
  if select(1, ...) then return end -- virtual / item placement
  oldInit(...)

  -- do stuff

  message.setHandler("gb2_cropshipper",
    function (_, _, args)
      if root.assetJson("/gardenbot2.config:noshipments") then return end
      local maxNum = world.containerSize(entity.id())
      local icount = #world.containerItems(entity.id())
      if (icount >= maxNum) then
        --	sb.logInfo("%s: %s / %s",world.entityName(entity.id()),icount,maxNum)
        local uicfg = config.getParameter("uiConfig")
        local sellFactor = root.assetJson(uicfg..":sellFactor")
        local pos = world.entityPosition(entity.id())
        local value = calcValueOfContents(sellFactor)
        dumpMoney(pos, value)
        world.sendEntityMessage(entity.id(), "triggerShipment")
      end
    end
  )
end

function spawnCash(p, v)
  world.spawnItem("money", {p[1] + (math.random(-1, 1) * 0.5), p[2] + 0.5}, v, root.itemConfig("money").parameters)
end

function dumpMoney(pos, value)
  --	sb.logInfo("dumpMoney: %s \n",value)
  while value >= 1000 do
    value = value - 1000
    spawnCash(pos, 1000)
  end
  spawnCash(pos, value)
end

function calcValueOfContents(sellFactor)
  local value = 0
  local allItems = world.containerItems(entity.id())
  for _, item in pairs(allItems) do
    if item.name == "money" then
      value = value + item.count
    else
      value = value + math.ceil((root.itemConfig(item).config.price or 0) * item.count * sellFactor)
    end
  end
  return value
end

--[[

in bot depositstate:
check if its a shipper -done
trigger shipment msg to here -done

here:
check if its full - size == #items
calc value of contents -done
spawn money @ obj pos -done
ship it -done woo

]]
