Gardenbot 2.1 (Starbound Mod) Readme
Released under the Apache 2.0 Licence
Original by Tynaut, Heavily modified by LoPhatKao.

Tired of manually farming crops? Chopping trees? Strip mining a planet for ore?
Then, these *are* the droids you're looking for. Welcome to Gardenbot!
